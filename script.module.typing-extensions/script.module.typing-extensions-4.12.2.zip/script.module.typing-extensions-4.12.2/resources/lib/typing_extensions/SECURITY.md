# Security Policy

## Supported Versions

Only the latest release is supported.

## Reporting a Vulnerability

To report an issue, go to https://github.com/python/typing_extensions/security.
We commit to respond to any issue within 14 days and promptly release any fixes.
