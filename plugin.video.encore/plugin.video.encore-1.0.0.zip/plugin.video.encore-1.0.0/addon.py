from os import environ
from pathlib import Path

from django.conf import settings
from django.core.management import execute_from_command_line
from django.db import connections
from django.urls import get_resolver


def execute():
    resolver = get_resolver()
    resolver_match = resolver.resolve(settings.URL.path)
    callback, callback_args, callback_kwargs = resolver_match
    callback(*callback_args, **callback_kwargs)


def main():
    environ.setdefault('DJANGO_SETTINGS_MODULE', 'encore.settings')
    Path(settings.PROFILE_DIR).mkdir(parents=True, exist_ok=True)

    try:
        if __debug__:
            execute_from_command_line([__file__, 'makemigrations', 'encore'])
        else:
            execute_from_command_line([__file__, 'migrate', 'encore'])
            execute()
    finally:
        connections.close_all()


if __name__ == '__main__':
    main()
