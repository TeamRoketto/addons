from dataclasses import dataclass
from typing import Dict, List, Optional, Union

from yt_dlp.utils.networking import HTTPHeaderDict


@dataclass
class Drama:
    bc: int
    bu: int
    e: str
    n: str
    p: str
    pid: str

    def __post_init__(self):
        self.p = f"https://tvbaw-na.s3.us-west-1.amazonaws.com/{self.p}"


@dataclass
class Categories:
    USA_Action: List[Drama]
    USA_AllDramas: List[Drama]
    USA_ATVDrama: List[Drama]
    USA_BehindTheScene: List[Drama]
    USA_BW_Movies: List[Drama]
    USA_Comedy: List[Drama]
    USA_Concert: List[Drama]
    USA_Detective_Drama: List[Drama]
    USA_Drama_History: List[Drama]
    USA_GP_Food: List[Drama]
    USA_GP_Info: List[Drama]
    USA_GP_News: List[Drama]
    USA_GP_Talkshow: List[Drama]
    USA_GP_Variety: List[Drama]
    USA_MegaMovie: List[Drama]
    USA_Romance: List[Drama]
    USA_Sci_Fi: List[Drama]
    USA_Sitcom: List[Drama]
    USA_SpecialProgram: List[Drama]
    USA_The_Classics: List[Drama]
    userRegion: str

    def __post_init__(self):
        self.USA_Action = list(map(lambda data: Drama(**data), self.USA_Action))
        self.USA_AllDramas = list(map(lambda data: Drama(**data), self.USA_AllDramas))
        self.USA_ATVDrama = list(map(lambda data: Drama(**data), self.USA_ATVDrama))
        self.USA_BehindTheScene = list(map(lambda data: Drama(**data), self.USA_BehindTheScene))
        self.USA_BW_Movies = list(map(lambda data: Drama(**data), self.USA_BW_Movies))
        self.USA_Comedy = list(map(lambda data: Drama(**data), self.USA_Comedy))
        self.USA_Concert = list(map(lambda data: Drama(**data), self.USA_Concert))
        self.USA_Detective_Drama = list(map(lambda data: Drama(**data), self.USA_Detective_Drama))
        self.USA_Drama_History = list(map(lambda data: Drama(**data), self.USA_Drama_History))
        self.USA_GP_Food = list(map(lambda data: Drama(**data), self.USA_GP_Food))
        self.USA_GP_Info = list(map(lambda data: Drama(**data), self.USA_GP_Info))
        self.USA_GP_News = list(map(lambda data: Drama(**data), self.USA_GP_News))
        self.USA_GP_Talkshow = list(map(lambda data: Drama(**data), self.USA_GP_Talkshow))
        self.USA_GP_Variety = list(map(lambda data: Drama(**data), self.USA_GP_Variety))
        self.USA_MegaMovie = list(map(lambda data: Drama(**data), self.USA_MegaMovie))
        self.USA_Romance = list(map(lambda data: Drama(**data), self.USA_Romance))
        self.USA_Sci_Fi = list(map(lambda data: Drama(**data), self.USA_Sci_Fi))
        self.USA_Sitcom = list(map(lambda data: Drama(**data), self.USA_Sitcom))
        self.USA_SpecialProgram = list(map(lambda data: Drama(**data), self.USA_SpecialProgram))
        self.USA_The_Classics = list(map(lambda data: Drama(**data), self.USA_The_Classics))


@dataclass
class DramaDetail:
    blockInCA: bool
    blockInUSA: bool
    pid: str
    poster: str
    title: str

    def __post_init__(self):
        self.poster = f"https://tvbaw-na.s3.us-west-1.amazonaws.com/{self.poster}"


@dataclass
class DramaInfo:
    adConfig: Optional[int] = None
    bannerPath: str
    bcov: str
    blockInCA: bool
    blockInUSA: bool
    char: List[str]
    genres: List[str]
    large: str
    pid: int
    posterPath: str
    status: str
    subtitle: str
    synopsis: str
    title: str
    year: str

    def __post_init__(self):
        self.bannerPath = f"https://tvbaw-na.s3.us-west-1.amazonaws.com/{self.bannerPath}"
        self.posterPath = f"https://tvbaw-na.s3.us-west-1.amazonaws.com/{self.posterPath}"


@dataclass
class Video:
    description: str
    name: str
    poster: str
    vid: int


@dataclass
class Format:
    acodec: Optional[str] = None
    abr: Optional[int] = None
    aspect_ratio: Optional[float] = None
    asr: Optional[int] = None
    audio_ext: str
    container: Optional[str] = None
    dynamic_range: Optional[str] = None
    ext: str
    filesize: Optional[int] = None
    format: str
    format_id: str
    format_index: Optional[int] = None
    format_note: Optional[str] = None
    fragment_base_url: Optional[str] = None
    fragments: Optional[Dict[str, str]] = None
    fps: Optional[float] = None
    has_drm: Optional[bool] = None
    height: Optional[int] = None
    http_headers: HTTPHeaderDict
    is_dash_periods: Optional[bool] = None
    language: Optional[str] = None
    manifest_stream_number: Optional[int] = None
    manifest_url: Optional[str] = None
    preference: Optional[str] = None
    protocol: str
    quality: Optional[str] = None
    resolution: str
    source_preference: Optional[int] = None
    tbr: Optional[float] = None
    url: str
    vbr: Optional[float] = None
    vcodec: str
    video_ext: str
    width: Optional[int] = None


@dataclass
class MetaData:
    _has_drm: None
    abr: None
    acodec: Optional[str] = None
    aspect_ratio: float
    asr: Optional[int] = None
    audio_channels: Optional[str] = None
    audio_ext: Optional[str] = None
    container: Optional[str] = None
    description: Optional[str] = None
    display_id: str
    duration: Optional[float] = None
    duration_string: Optional[str] = None
    dynamic_range: str
    epoch: int
    ext: str
    extractor: str
    extractor_key: str
    filesize: Optional[int] = None
    filesize_approx: Optional[int] = None
    format: str
    format_id: str
    format_index: Optional[int] = None
    format_note: Optional[str] = None
    formats: List[Format]
    fps: Optional[float] = None
    fulltitle: str
    has_drm: Optional[bool] = None
    height: int
    http_headers: Optional[HTTPHeaderDict] = None
    id: str
    is_live: bool
    language: Optional[str] = None
    live_status: Optional[str] = None
    manifest_url: Optional[str] = None
    original_url: str
    playlist: None
    playlist_index: None
    preference: Optional[str] = None
    protocol: str
    quality: Optional[str] = None
    release_year: None
    requested_formats: Optional[Dict[str, Union[bool, float, int, str, HTTPHeaderDict, None]]] = None
    requested_subtitles: None
    resolution: str
    source_preference: Optional[int] = None
    stretched_ratio: Optional[float] = None
    subtitles: Dict[str, str]
    tags: List[str]
    tbr: float
    thumbnail: str
    thumbnails: List[Dict[str, Union[int, str]]]
    timestamp: int
    title: str
    upload_date: Optional[str] = None
    uploader_id: str
    url: Optional[str] = None
    vbr: None
    vcodec: str
    video_ext: Optional[str] = None
    was_live: Optional[bool] = None
    webpage_url: str
    webpage_url_basename: str
    webpage_url_domain: str
    width: int

    def __post_init__(self):
        self.formats = list(map(lambda data: Format(**data), self.formats))
