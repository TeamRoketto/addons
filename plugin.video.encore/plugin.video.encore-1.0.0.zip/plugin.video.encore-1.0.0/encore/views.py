from os.path import join

from django.conf import settings
from xbmc import executebuiltin
from xbmcaddon import Addon
from xbmcgui import Dialog, ListItem
from xbmcplugin import addDirectoryItems, endOfDirectory, setContent, setResolvedUrl

from encore import apis
from encore.models import History

addon = Addon()


def home():
    items = [
        ListItem(addon.getLocalizedString(30000), f"{settings.HOST}/history"),
        ListItem(addon.getLocalizedString(30001), f"{settings.HOST}/live"),
        ListItem(addon.getLocalizedString(30002), f"{settings.HOST}/categories"),
    ]

    items[0].setArt({"icon": "DefaultTags.png"})
    items[1].setArt({"icon": "DefaultAddonTvInfo.png"})
    items[2].setArt({"icon": "DefaultTVShows.png"})

    addDirectoryItems(settings.HANDLE, [(item.getLabel2(), item, True) for item in items])
    endOfDirectory(settings.HANDLE)


def history():
    items = []

    for history in History.objects.all().order_by("-updated_at"):
        drama = apis.get_drama_by_pid(history.pid)
        item = ListItem(drama.title)
        item.addContextMenuItems(
            [
                (addon.getLocalizedString(30100), f"RunPlugin({settings.HOST}/history/delete/{history.pid})"),
                (addon.getLocalizedString(30101), f"RunPlugin({settings.HOST}/history/delete)"),
            ]
        )
        item.setArt({"poster": drama.posterPath})
        item.setInfo(
            "video",
            {
                "cast": drama.char,
                "genre": drama.genres,
                "originaltitle": drama.subtitle,
                "plot": drama.synopsis,
                "status": drama.status,
                "title": drama.title,
                "year": int("".join(filter(str.isdigit, drama.year))),
            },
        )
        items.append((f"{settings.HOST}/series/{drama.pid}/videos", item, True))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "tvshows")
    endOfDirectory(settings.HANDLE)


def history_delete():
    History.objects.all().delete()
    executebuiltin("Container.Refresh")


def history_delete_pid(pid: int):
    History.objects.filter(pid=pid).delete()
    executebuiltin("Container.Refresh")


def live():
    items = [
        ListItem(addon.getLocalizedString(30200), f"{settings.HOST}/live/j1"),
        ListItem(addon.getLocalizedString(30201), f"{settings.HOST}/live/news"),
    ]

    for item in items:
        item.setInfo("video", {"title": item.getLabel()})
        item.setProperty("IsPlayable", "true")

    items[0].setArt({"poster": "https://encoretvb-app.s3-us-west-1.amazonaws.com/live/tvb-j1-thumb.jpg"})
    items[1].setArt({"poster": "https://encoretvb-app.s3-us-west-1.amazonaws.com/live/tvb-news-thumb.jpg"})

    addDirectoryItems(settings.HANDLE, [(item.getLabel2(), item, False) for item in items])
    setContent(settings.HANDLE, "episodes")
    endOfDirectory(settings.HANDLE)


def live_j1():
    j1 = apis.get_live_j1()
    item = ListItem(j1.title)
    item.setPath(j1.url)
    setResolvedUrl(settings.HANDLE, True, item)


def live_news():
    news = apis.get_live_news()
    item = ListItem(news.title)
    item.setPath(news.url)
    setResolvedUrl(settings.HANDLE, True, item)


def categories():
    items = [
        ListItem(addon.getLocalizedString(30300), f"{settings.HOST}/categories/USA_AllDramas"),
        ListItem(addon.getLocalizedString(30306), f"{settings.HOST}/categories/USA_Action"),
        ListItem(addon.getLocalizedString(30315), f"{settings.HOST}/categories/USA_ATVDrama"),
        ListItem(addon.getLocalizedString(30319), f"{settings.HOST}/categories/USA_BehindTheScene"),
        ListItem(addon.getLocalizedString(30318), f"{settings.HOST}/categories/USA_BW_Movies"),
        ListItem(addon.getLocalizedString(30304), f"{settings.HOST}/categories/USA_Comedy"),
        ListItem(addon.getLocalizedString(30317), f"{settings.HOST}/categories/USA_Concert"),
        ListItem(addon.getLocalizedString(30302), f"{settings.HOST}/categories/USA_Detective_Drama"),
        ListItem(addon.getLocalizedString(30303), f"{settings.HOST}/categories/USA_Drama_History"),
        ListItem(addon.getLocalizedString(30312), f"{settings.HOST}/categories/USA_GP_Food"),
        ListItem(addon.getLocalizedString(30311), f"{settings.HOST}/categories/USA_GP_Info"),
        ListItem(addon.getLocalizedString(30309), f"{settings.HOST}/categories/USA_GP_News"),
        ListItem(addon.getLocalizedString(30313), f"{settings.HOST}/categories/USA_GP_Talkshow"),
        ListItem(addon.getLocalizedString(30310), f"{settings.HOST}/categories/USA_GP_Variety"),
        ListItem(addon.getLocalizedString(30316), f"{settings.HOST}/categories/USA_MegaMovie"),
        ListItem(addon.getLocalizedString(30305), f"{settings.HOST}/categories/USA_Romance"),
        ListItem(addon.getLocalizedString(30307), f"{settings.HOST}/categories/USA_Sci_Fi"),
        ListItem(addon.getLocalizedString(30301), f"{settings.HOST}/categories/USA_Sitcom"),
        ListItem(addon.getLocalizedString(30314), f"{settings.HOST}/categories/USA_SpecialProgram"),
        ListItem(addon.getLocalizedString(30308), f"{settings.HOST}/categories/USA_The_Classics"),
    ]

    for item in items:
        item.setArt({"icon": "DefaultTVShows.png"})

    addDirectoryItems(settings.HANDLE, [(item.getLabel2(), item, True) for item in items])
    endOfDirectory(settings.HANDLE)


def category(category: str):
    items = []

    for drama in getattr(apis.get_categories(), category):
        item = ListItem(drama.n)
        item.setArt({"poster": drama.p})
        item.setInfo("video", {"title": drama.e, "originaltitle": drama.n})
        item.addContextMenuItems(
            [
                (addon.getLocalizedString(30400), f"RunPlugin({settings.HOST}/series/{drama.pid}/artists)"),
                (addon.getLocalizedString(30401), f"RunPlugin({settings.HOST}/series/{drama.pid}/genres)"),
                (addon.getLocalizedString(30402), f"RunPlugin({settings.HOST}/series/{drama.pid}/years)"),
            ]
        )
        items.append((f"{settings.HOST}/series/{drama.pid}/videos", item, True))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "tvshows")
    endOfDirectory(settings.HANDLE)


def artists(pid: int):
    drama = apis.get_drama_by_pid(pid)
    index = Dialog().select(addon.getLocalizedString(30400), drama.char)

    if index < 0:
        return

    executebuiltin(f"ActivateWindow(Videos,{settings.HOST}/artists/{drama.char[index]},return)")


def artist(artist: str):
    items = []

    for drama in apis.get_dramas_by_artist(artist):
        item = ListItem(drama.title)
        item.setArt({"poster": drama.poster})
        item.setInfo("video", {"title": drama.title})
        items.append((f"{settings.HOST}/series/{drama.pid}/videos", item, True))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "tvshows")
    endOfDirectory(settings.HANDLE)


def genres(pid: int):
    drama = apis.get_drama_by_pid(pid)
    index = Dialog().select(addon.getLocalizedString(30401), drama.genres)

    if index < 0:
        return

    executebuiltin(f"ActivateWindow(Videos,{settings.HOST}/genres/{drama.genres[index]},return)")


def genre(genre: str):
    items = []

    for drama in apis.get_dramas_by_genre(genre):
        item = ListItem(drama.title)
        item.setArt({"poster": drama.poster})
        item.setInfo("video", {"title": drama.title})
        items.append((f"{settings.HOST}/series/{drama.pid}/videos", item, True))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "tvshows")
    endOfDirectory(settings.HANDLE)


def videos(pid: int):
    items = []

    for video in apis.get_videos_by_pid(pid):
        item = ListItem(video.name)
        item.setArt({"poster": video.poster})
        item.setInfo("video", {"plot": video.description, "title": video.name})
        item.setProperty("IsPlayable", "true")
        items.append((f"{settings.HOST}/videos/{pid}/{video.vid}", item, False))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "episodes")
    endOfDirectory(settings.HANDLE)


def years(pid: int):
    drama = apis.get_drama_by_pid(pid)
    index = Dialog().select(addon.getLocalizedString(30402), [drama.year])

    if index < 0:
        return

    executebuiltin(f"ActivateWindow(Videos,{settings.HOST}/years/{drama.year},return)")


def year(year: str):
    items = []

    for drama in apis.get_dramas_by_year(year):
        item = ListItem(drama.title)
        item.setArt({"poster": drama.poster})
        item.setInfo("video", {"title": drama.title})
        items.append((f"{settings.HOST}/series/{drama.pid}/videos", item, True))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "tvshows")
    endOfDirectory(settings.HANDLE)


def video(pid: int, vid: int):
    History.objects.update_or_create(pid=pid, defaults={"pid": pid})
    video = apis.get_video_by_vid(pid, vid)
    item = ListItem(video.title)

    if addon.getSettingBool("automaticvideo") and video.url:
        path = video.url
    else:
        path = join(settings.DATA_DIR, "main.m3u8")

        if addon.getSettingBool("automaticvideo"):
            videos = list(filter(lambda format: format.audio_ext == "none", video.formats))
            audios = list(filter(lambda format: format.ext == "mp4" and format.language == "yue", video.formats))
            video_index = -1
            audio_index = -1
        else:
            videos = list(filter(lambda format: format.audio_ext == "none", video.formats))
            audios = list(filter(lambda format: format.video_ext == "none", video.formats))

            video_index = Dialog().select(addon.getLocalizedString(30600), [video_info.format for video_info in videos])
            if video_index < 0:
                return

            audio_index = Dialog().select(addon.getLocalizedString(30601), [audio_info.format for audio_info in audios])
            if audio_index < 0:
                return

        video_info = videos[video_index]
        audio_info = audios[audio_index]

        with open(path, "w") as main:
            m3u8 = '#EXTM3U\n\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="{}",URI="{}"\n\n#EXT-X-STREAM-INF:AUDIO="{}"\n{}'
            main.write(m3u8.format(audio_info.format_id, audio_info.url, audio_info.format_id, video_info.url))

    item.setPath(path)
    setResolvedUrl(settings.HANDLE, True, item)
