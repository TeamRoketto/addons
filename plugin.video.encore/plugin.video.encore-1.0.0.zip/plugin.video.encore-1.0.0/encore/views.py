from os.path import join

from django.conf import settings
from xbmc import executebuiltin
from xbmcaddon import Addon
from xbmcgui import Dialog, ListItem
from xbmcplugin import addDirectoryItems, endOfDirectory, setContent, setResolvedUrl

from encore import apis
from encore.models import History

getString = Addon().getLocalizedString


def home():
    items = [
        ListItem(getString(30000), f"{settings.HOST}/history"),
        ListItem(getString(30001), f"{settings.HOST}/live"),
        ListItem(getString(30002), f"{settings.HOST}/categories"),
    ]

    items[0].setArt({"icon": "DefaultTags.png"})
    items[1].setArt({"icon": "DefaultAddonTvInfo.png"})
    items[2].setArt({"icon": "DefaultTVShows.png"})

    addDirectoryItems(settings.HANDLE, [(item.getLabel2(), item, True) for item in items])
    endOfDirectory(settings.HANDLE)


def history():
    items = []

    for history in History.objects.all().order_by("-updated_at"):
        drama = apis.get_drama_by_pid(history.pid)
        item = ListItem(drama.title)
        item.addContextMenuItems(
            [
                (getString(30100), f"RunPlugin({settings.HOST}/history/delete/{history.pid})"),
                (getString(30101), f"RunPlugin({settings.HOST}/history/delete)"),
            ]
        )
        item.setArt({"poster": drama.posterPath})
        item.setInfo(
            "video",
            {
                "cast": drama.char,
                "genre": drama.genres,
                "plot": drama.synopsis,
                "status": drama.status,
                "year": int(drama.year),
            },
        )
        items.append((f"{settings.HOST}/series/{drama.pid}", item, True))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "tvshows")
    endOfDirectory(settings.HANDLE)


def history_delete():
    History.objects.all().delete()
    executebuiltin("Container.Refresh")


def history_delete_pid(pid: int):
    History.objects.filter(pid=pid).delete()
    executebuiltin("Container.Refresh")


def live():
    items = [
        ListItem(getString(30200), f"{settings.HOST}/live/j1"),
        ListItem(getString(30201), f"{settings.HOST}/live/news"),
    ]

    for item in items:
        item.setInfo("video", {})
        item.setProperty("IsPlayable", "true")

    items[0].setArt({"poster": "https://encoretvb-app.s3-us-west-1.amazonaws.com/live/tvb-j1-thumb.jpg"})
    items[1].setArt({"poster": "https://encoretvb-app.s3-us-west-1.amazonaws.com/live/tvb-news-thumb.jpg"})

    addDirectoryItems(settings.HANDLE, [(item.getLabel2(), item, False) for item in items])
    setContent(settings.HANDLE, "episodes")
    endOfDirectory(settings.HANDLE)


def live_j1():
    j1 = apis.get_live_j1()
    item = ListItem(j1.title)
    item.setPath(j1.url)
    setResolvedUrl(settings.HANDLE, True, item)


def live_news():
    news = apis.get_live_news()
    item = ListItem(news.title)
    item.setPath(news.url)
    setResolvedUrl(settings.HANDLE, True, item)


def categories():
    items = [
        ListItem(getString(30300), f"{settings.HOST}/categories/USA_AllDramas"),
        ListItem(getString(30306), f"{settings.HOST}/categories/USA_Action"),
        ListItem(getString(30315), f"{settings.HOST}/categories/USA_ATVDrama"),
        ListItem(getString(30319), f"{settings.HOST}/categories/USA_BehindTheScene"),
        ListItem(getString(30318), f"{settings.HOST}/categories/USA_BW_Movies"),
        ListItem(getString(30304), f"{settings.HOST}/categories/USA_Comedy"),
        ListItem(getString(30317), f"{settings.HOST}/categories/USA_Concert"),
        ListItem(getString(30302), f"{settings.HOST}/categories/USA_Detective_Drama"),
        ListItem(getString(30303), f"{settings.HOST}/categories/USA_Drama_History"),
        ListItem(getString(30312), f"{settings.HOST}/categories/USA_GP_Food"),
        ListItem(getString(30311), f"{settings.HOST}/categories/USA_GP_Info"),
        ListItem(getString(30309), f"{settings.HOST}/categories/USA_GP_News"),
        ListItem(getString(30313), f"{settings.HOST}/categories/USA_GP_Talkshow"),
        ListItem(getString(30310), f"{settings.HOST}/categories/USA_GP_Variety"),
        ListItem(getString(30316), f"{settings.HOST}/categories/USA_MegaMovie"),
        ListItem(getString(30305), f"{settings.HOST}/categories/USA_Romance"),
        ListItem(getString(30307), f"{settings.HOST}/categories/USA_Sci_Fi"),
        ListItem(getString(30301), f"{settings.HOST}/categories/USA_Sitcom"),
        ListItem(getString(30314), f"{settings.HOST}/categories/USA_SpecialProgram"),
        ListItem(getString(30308), f"{settings.HOST}/categories/USA_The_Classics"),
    ]

    for item in items:
        item.setArt({"icon": "DefaultTVShows.png"})

    addDirectoryItems(settings.HANDLE, [(item.getLabel2(), item, True) for item in items])
    endOfDirectory(settings.HANDLE)


def category(category: str):
    items = []

    for drama in getattr(apis.get_categories(), category):
        item = ListItem(drama.n)
        item.setArt({"poster": drama.p})
        item.setInfo("video", {"plot": drama.e})
        item.addContextMenuItems(
            [
                (getString(30400), f"RunPlugin({settings.HOST}/series/{drama.pid}/artists)"),
                (getString(30401), f"RunPlugin({settings.HOST}/series/{drama.pid}/genres)"),
                (getString(30402), f"RunPlugin({settings.HOST}/series/{drama.pid}/years)"),
            ]
        )
        items.append((f"{settings.HOST}/series/{drama.pid}/videos", item, True))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "tvshows")
    endOfDirectory(settings.HANDLE)


def artists(pid: int):
    drama = apis.get_drama_by_pid(pid)
    index = Dialog().select(getString(30400), drama.char)

    if index < 0:
        return

    executebuiltin(f"ActivateWindow(Videos,{settings.HOST}/artists/{drama.char[index]},return)")


def artist(artist: str):
    items = []

    for drama in apis.get_dramas_by_artist(artist):
        item = ListItem(drama.title)
        item.setArt({"poster": drama.poster})
        items.append((f"{settings.HOST}/series/{drama.pid}/videos", item, True))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "tvshows")
    endOfDirectory(settings.HANDLE)


def genres(pid: int):
    drama = apis.get_drama_by_pid(pid)
    index = Dialog().select(getString(30401), drama.genres)

    if index < 0:
        return

    executebuiltin(f"ActivateWindow(Videos,{settings.HOST}/genres/{drama.genres[index]},return)")


def genre(genre: str):
    items = []

    for drama in apis.get_dramas_by_genre(genre):
        item = ListItem(drama.title)
        item.setArt({"poster": drama.poster})
        items.append((f"{settings.HOST}/series/{drama.pid}/videos", item, True))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "tvshows")
    endOfDirectory(settings.HANDLE)


def videos(pid: int):
    items = []

    for video in apis.get_videos_by_pid(pid):
        item = ListItem(video.name)
        item.setArt({"poster": video.poster})
        item.setInfo("video", {"plot": video.description})
        item.setProperty("IsPlayable", "true")
        items.append((f"{settings.HOST}/videos/{pid}/{video.vid}", item, False))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "episodes")
    endOfDirectory(settings.HANDLE)


def years(pid: int):
    drama = apis.get_drama_by_pid(pid)
    index = Dialog().select(getString(30403), [drama.year])

    if index < 0:
        return

    executebuiltin(f"ActivateWindow(Videos,{settings.HOST}/years/{drama.year},return)")


def year(year: str):
    items = []

    for drama in apis.get_dramas_by_year(year):
        item = ListItem(drama.title)
        item.setArt({"poster": drama.poster})
        items.append((f"{settings.HOST}/series/{drama.pid}/videos", item, True))

    addDirectoryItems(settings.HANDLE, items)
    setContent(settings.HANDLE, "tvshows")
    endOfDirectory(settings.HANDLE)


def video(pid: int, vid: int):
    History.objects.update_or_create(pid=pid, defaults={"pid": pid})
    video = apis.get_video_by_vid(pid, vid)
    item = ListItem(video.title)

    if video.url:
        path = video.url
    else:
        path = join(settings.DATA_DIR, "main.m3u8")
        videos = list(filter(lambda format: format.audio_ext == "none", video.formats))
        audios = list(filter(lambda format: format.ext == "mp4" and format.language == "yue", video.formats))

        with open(path, "w") as main:
            m3u8 = '#EXTM3U\n\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="{}",URI="{}"\n\n#EXT-X-STREAM-INF:AUDIO="{}"\n{}'
            main.write(m3u8.format(audios[-1].format_id, audios[-1].url, audios[-1].format_id, videos[-1].url))

    item.setPath(path)
    setResolvedUrl(settings.HANDLE, True, item)
