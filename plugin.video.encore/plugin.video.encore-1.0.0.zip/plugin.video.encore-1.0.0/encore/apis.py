from typing import List

from bs4 import BeautifulSoup, SoupStrainer
from django.conf import settings
from requests_cache import CachedSession
from yt_dlp import YoutubeDL

from encore.dtos import Categories, DramaDetail, DramaInfo, MetaData, Video


def get_categories() -> Categories:
    response = session.get("https://pmv4k0zsuc.execute-api.us-west-2.amazonaws.com/v1/content")
    json = response.json()
    return Categories(**json)


def get_dramas_by_artist(artist: str) -> List[DramaDetail]:
    response = session.post("https://us-central1-tvbaw-na-backend.cloudfunctions.net/getPidByArtist", {"value": artist})
    json = response.json()
    return list(map(lambda data: DramaDetail(**data), json))


def get_dramas_by_genre(genre: str) -> List[DramaDetail]:
    response = session.post("https://us-central1-tvbaw-na-backend.cloudfunctions.net/getPidByGenre", {"value": genre})
    json = response.json()
    return list(map(lambda data: DramaDetail(**data), json))


def get_dramas_by_year(year: str) -> List[DramaDetail]:
    response = session.post("https://us-central1-tvbaw-na-backend.cloudfunctions.net/getPidByYear", {"value": year})
    json = response.json()
    return list(map(lambda data: DramaDetail(**data), json))


def get_drama_by_pid(pid: int) -> DramaInfo:
    response = session.get("https://api.tvbaw.com/getProgramByPid", params={"value": pid})
    json = response.json()
    return DramaInfo(**json)


def get_videos_by_pid(pid: int) -> List[Video]:
    response = session.get(f"https://www.tvbanywherena.com/cantonese/series/{pid}")
    parse_only = SoupStrainer("div", {"class": "item nopadding"})
    document = BeautifulSoup(response.text, "html.parser", parse_only=parse_only)
    videos = []

    for element in document.contents:
        video = {
            "description": element.find_next("div", {"class": "episodeDescription"}).get_text(),
            "name": element.find_next("div", {"class": "episodeName"}).get_text(),
            "poster": element.find_next("img").attrs["src"],
            "vid": int(element.find_next("a").attrs["href"].split("/")[-1]),
        }
        videos.append(Video(**video))

    return videos


def get_video_by_vid(pid: int, vid: int) -> MetaData:
    with YoutubeDL({"geo_bypass_country": "CA"}) as ydl:
        info = ydl.extract_info(f"https://www.tvbanywherena.com/cantonese/videos/{pid}/{vid}", False)
        return MetaData(**info)


def get_live_j1() -> MetaData:
    with YoutubeDL({"geo_bypass_country": "CA"}) as ydl:
        info = ydl.extract_info(f"https://tvbanywherena.com/cantonese/live/tvb-j1", False)
        return MetaData(**info)


def get_live_news() -> MetaData:
    with YoutubeDL({"geo_bypass_country": "CA"}) as ydl:
        info = ydl.extract_info(f"https://tvbanywherena.com/cantonese/live/tvb-news", False)
        return MetaData(**info)


session = CachedSession(settings.CACHE_NAME, expire_after=600)
