from django.urls import path

from encore import views

urlpatterns = [
    path("", views.home),
    path("history", views.history),
    path("history/delete", views.history_delete),
    path("history/delete/<int:pid>", views.history_delete_pid),
    path("live", views.live),
    path("live/j1", views.live_j1),
    path("live/news", views.live_news),
    path("categories", views.categories),
    path("categories/<str:category>", views.category),
    path("series/<int:pid>/artists", views.artists),
    path("series/<int:pid>/genres", views.genres),
    path("series/<int:pid>/videos", views.videos),
    path("series/<int:pid>/years", views.years),
    path("artists/<str:artist>", views.artist),
    path("genres/<str:genre>", views.genre),
    path("years/<int:year>", views.year),
    path("videos/<int:pid>/<int:vid>", views.video),
]
