from os.path import join
from sys import argv
from urllib.parse import urlsplit, urlunsplit

from xbmcaddon import Addon
from xbmcvfs import translatePath

BASE_DIR = translatePath(Addon().getAddonInfo("path"))

DATA_DIR = join(BASE_DIR, "resources", "data")

PROFILE_DIR = translatePath(Addon().getAddonInfo("profile"))

CACHE_NAME = join(DATA_DIR, "http_cache")

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": join(PROFILE_DIR, "db.sqlite3"),
    }
}

INSTALLED_APPS = ["encore"]

ROOT_URLCONF = "encore.urls"

URL = urlsplit("" if __debug__ else argv[0])

HANDLE = -1 if __debug__ else int(argv[1])

HOST = urlunsplit((URL.scheme, URL.netloc, "", "", ""))
