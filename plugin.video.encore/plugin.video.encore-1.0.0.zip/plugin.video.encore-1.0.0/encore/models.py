from django.db.models import DateTimeField, IntegerField, Model


class BaseModel(Model):
    created_at = DateTimeField(auto_now_add=True)
    updated_at = DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class History(BaseModel):
    pid = IntegerField(unique=True)
