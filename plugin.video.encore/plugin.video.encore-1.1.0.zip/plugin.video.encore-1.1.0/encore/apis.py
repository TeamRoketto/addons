from re import compile
from typing import List

from django.conf import settings
from requests_cache import CachedSession
from yt_dlp import YoutubeDL

from encore.dtos import Categories, Channels, DramaDetail, DramaInfo, MetaData, Video


def get_categories() -> Categories:
    response = session.get("https://pmv4k0zsuc.execute-api.us-west-2.amazonaws.com/v1/content")
    json = response.json()
    return Categories(**json)


def get_dramas_by_artist(artist: str) -> List[DramaDetail]:
    response = session.post("https://us-central1-tvbaw-na-backend.cloudfunctions.net/getPidByArtist", {"value": artist})
    json = response.json()
    return list(map(lambda data: DramaDetail(**data), json))


def get_dramas_by_genre(genre: str) -> List[DramaDetail]:
    response = session.post("https://us-central1-tvbaw-na-backend.cloudfunctions.net/getPidByGenre", {"value": genre})
    json = response.json()
    return list(map(lambda data: DramaDetail(**data), json))


def get_dramas_by_year(year: str) -> List[DramaDetail]:
    response = session.post("https://us-central1-tvbaw-na-backend.cloudfunctions.net/getPidByYear", {"value": year})
    json = response.json()
    return list(map(lambda data: DramaDetail(**data), json))


def get_drama_by_pid(pid: int) -> DramaInfo:
    response = session.get("https://api.tvbaw.com/getProgramByPid", params={"value": pid})
    json = response.json()
    return DramaInfo(**json)


def get_videos_by_pid(pid: int) -> List[Video]:
    response = session.get(f"https://www.tvbanywherena.com/series/{pid}")
    matches = compile(
        r'\\"id\\":\\"(\d+)\\",.*?'
        r'\\"title_chi\\":\\"(.*?)\\",.*?'
        r'\\"description\\":(.*?),.*?'
        r'\\"duration\\":(\d+),.*?'
        r'\\"src\\":\\"(https://cf-images\.us-east-1\.prod\.boltdns\.net/.*?)\\",'
    ).findall(response.text)
    videos = []

    for vid, name, description, duration, poster in matches:
        video = {
            "description": "" if description == "null" else description,
            "duration": int(int(duration) / 1000),
            "name": name,
            "poster": poster,
            "vid": int(vid),
        }
        videos.append(Video(**video))

    return videos


def get_video_by_vid(pid: int, vid: int) -> MetaData:
    response = session.get(f"https://www.tvbanywherena.com/watch/{pid}/{vid}")
    embedUrl = compile(r'"embedUrl":"(.*?)"').search(response.text).group(1)

    with YoutubeDL(params) as ydl:
        info = ydl.extract_info(embedUrl, False)
        return MetaData(**info)


def get_live_j1() -> MetaData:
    with YoutubeDL(params) as ydl:
        info = ydl.extract_info("https://players.brightcove.net/5324042807001/7yCKrx1jFl_default/index.html?videoId=1805631954506158911", False)
        return MetaData(**info)


def get_live_news() -> Channels:
    response = session.post("https://news.tvb.com/app/public/live/stream/C")
    json = response.json()
    return Channels(**json)


def get_live_pearl() -> MetaData:
    with YoutubeDL(params) as ydl:
        info = ydl.extract_info("https://players.brightcove.net/5324042807001/7yCKrx1jFl_default/index.html?videoId=1784555377807722630", False)
        return MetaData(**info)


params = {
    "geo_bypass_country": "CA",
    "http_headers": {
        "Origin": "https://tvbanywherena.com",
    },
}
session = CachedSession(settings.CACHE_NAME, expire_after=600)
